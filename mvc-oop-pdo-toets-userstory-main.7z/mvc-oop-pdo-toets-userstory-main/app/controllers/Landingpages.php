<?php 

class Landingpages extends Controller
{
    public function __construct() 
    {
        
    }

    public function index()
    {
        echo 'indexpage';
    }
}