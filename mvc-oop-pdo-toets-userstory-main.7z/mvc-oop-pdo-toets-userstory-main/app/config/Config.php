<?php 
    //DB Constanten
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'mvc');

    //URL Constanten
    define('APPROOT', dirname(dirname(__FILE__)));
    define('URLROOT', 'http://mvc-oop-pdo-toets-userstory.com');
    define('SITENAME', 'MVC Framework');
?>